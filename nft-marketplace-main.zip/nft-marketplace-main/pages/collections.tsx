import {Catalog} from 'modules/Collections/Catalog'

export default function Create() {
  return <Catalog />
}