import { Creator } from 'modules/Creator'

export default function Create() {
  return <Creator />
}
