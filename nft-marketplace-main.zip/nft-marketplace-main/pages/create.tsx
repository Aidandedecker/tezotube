import { CreateNonFungiblePage } from 'modules/CreateNonFungiblePage'

export default function Create() {
  return <CreateNonFungiblePage />
}
