import { Catalog } from 'modules/Marketplace/Catalog'

export default function Home() {
  return <Catalog />
}