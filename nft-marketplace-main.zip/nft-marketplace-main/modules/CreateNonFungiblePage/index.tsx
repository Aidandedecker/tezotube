export { default as CreateNonFungiblePage } from './CreateNonFungiblePage'
